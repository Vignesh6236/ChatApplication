package client.conn;

import intf.MessageInterface;  // import the created interface
import java.io.*; // used to import isr and osw
import java.net.*; //used to import socket classes
public class Client {
    private static Client instance;
    private Socket socketConn;
    private InputStreamReader isr; //used to decode the charecter from the bytes
    private OutputStreamWriter osw; // used to encode charecters to bytes
    
    private MessageInterface mi;
    
    public static Client getInstance(){
        if(instance == null){
            instance = new Client();
        }
        return instance;
    }
    //Instance is a variable defined outside the method but in class
    public void connectToServer(MessageInterface mi) throws Exception{
        this.mi = mi;
        System.out.println("Connection to server...");
        socketConn = new Socket("localhost", 3535);
//the client connects to the ip address and port where the server is connected
//this contains the ip address and port to which the server is connected
        isr = new InputStreamReader(socketConn.getInputStream());
//takes input from the server
        osw = new OutputStreamWriter(socketConn.getOutputStream());
//contaions the output data
        System.out.println("Conneted to server");
        listenForMessages();
//calls the abouve function  
    }
    
    public void listenForMessages(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    try{
                        char[] charMessage = new char[1024];
//definig the written message as array of charecters
//the array size is 1024 therefore,only a message having a length of 1024 cannot exceed the message can be of 1024 or less than 1024
                        if(isr.read(charMessage, 0, charMessage.length) != -1){
//this if statment tells that if the message length is not equal to -1 then execute the folliwing statements present in if
                            String message = new String(charMessage);
//defining a string that now contains the charecters that r present in the array of charecters
                            mi.onMessageReceived(message);
//calling the abstract method from the interface
                            System.out.println(message);
                        }
                    }catch(Exception e){
                        System.err.println(e.getMessage());
                    }
                }
            }
        }).start();
    }
// this part of the code is used to send message from the client to the server
    public void sendMessage(String message)throws Exception{
        osw.write(message);
        osw.flush();// writes the the message from the client to the server
    }
}
