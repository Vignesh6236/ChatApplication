package server.conn;

import intf.MessageInterface;  // import the created interface
import java.io.*; // used to import isr and osw
import java.net.*; //used to import serverscoket and socket classes
public class Server {
    
    public static Server instance;
    private ServerSocket serverSocket;  // serversocket class obj //predefined class
    private Socket socket; // sockett class obj //predefined class
    private InputStreamReader isr; //used to decode the charecter from the bytes
    private OutputStreamWriter osw; // used to encode charecters to bytes
    
    private MessageInterface mi;
    
    public static Server getInstance(){
        if(instance == null){
            instance = new Server();
        }
        return instance;
    }
    //Instance is a variable defined outside the method but in class
    public void startServer(MessageInterface mi) throws Exception{
        this.mi = mi;
        serverSocket = new ServerSocket(3535); // the server connects to the port 3535 
        // the client and the server should be connected to same port to establish the connection between the server and the client
        // after the client is connected a new thread is created which takes and sends data that has to displayed on the server and client respectively
        new Thread(new Runnable() { 
            @Override
            public void run() {
                while(true){
                    try{ //using try n catch exception
                        System.out.println("Server online..."); 
                        socket = serverSocket.accept(); // this class accepts the data 
                        isr = new InputStreamReader(socket.getInputStream());  //takes input from the client socket  
                        //socket. since all the data comes form the socket class therefore socket.is used
                        osw = new OutputStreamWriter(socket.getOutputStream());  //contains the output data
                        //socket. since all the data comes form the socket class therefore socket.is used
                        System.out.println("Client Server Connection OK");
                        listenForMessages();
                        //calls the above function
                        break;
                    }
                    catch (Exception e){
                        System.err.println("Server Listening Error!");
                    }
                }
            }
        }).start();
    }
    //takes the input from client and dispays it into the server text area
    public void listenForMessages(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    try{
                        char[] charMessage = new char[1024];
//definig the written messahe as array of charecters
//the array size is 1024 therefore,only a message having a length of 1024 cannot exceed the message can be of 1024 or less than 1024 
                        if(isr.read(charMessage, 0, charMessage.length) != -1){
//this if statment tells that if the message length is not equal to -1 then execute the folliwing statements present in if  
                            String message = new String(charMessage);
//defining a string that now contains the charecters that r present in the array of charecters 
                            mi.onMessageReceived(message);
//calling the abstract method from the interface
                            System.out.println(message);
                        }
                    }catch(Exception e){
                        System.err.println(e.getMessage());
                    }
                }
            }
        }).start();
    }
    // this part of the code is used to send message from the server to the client
    public void sendMessage(String message)throws Exception{
        osw.write(message);
        osw.flush();// writes the the message from the sever to the client
    }
}
 