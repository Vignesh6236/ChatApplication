package intf;
public interface MessageInterface {
    void onMessageReceived(String message);
}